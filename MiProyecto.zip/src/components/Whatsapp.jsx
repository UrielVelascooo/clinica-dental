import React, { useState, useEffect } from "react";

function Whatsapp() {
  const phone = "521234567890"; 
  const [showTooltip, setShowTooltip] = useState(false);

  
  useEffect(() => {
    const timer = setTimeout(() => setShowTooltip(true), 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div style={styles.wrapper}>
      
      <div style={{
        ...styles.tooltip,
        opacity: showTooltip ? 1 : 0,
        transform: showTooltip ? "translateX(0)" : "translateX(20px)"
      }}>
        <span style={styles.statusDot}></span>
        ¿Necesitas ayuda? ¡Escríbenos!
        <button 
          onClick={() => setShowTooltip(false)} 
          style={styles.closeTooltip}
        >✕</button>
      </div>

      
      <a
        href={`https://wa.me/${phone}`}
        target="_blank"
        rel="noopener noreferrer"
        style={styles.button}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = "scale(1.1) translateY(-5px)";
          e.currentTarget.style.boxShadow = "0 15px 30px rgba(37, 211, 102, 0.4)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = "scale(1) translateY(0)";
          e.currentTarget.style.boxShadow = "0 10px 25px rgba(0,0,0,0.15)";
        }}
      >
        <svg 
          width="30" 
          height="30" 
          viewBox="0 0 24 24" 
          fill="white"
        >
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      </a>
    </div>
  );
}

const styles = {
  wrapper: {
    position: "fixed",
    bottom: "30px",
    right: "30px",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
    zIndex: 9999,
    fontFamily: "'Inter', sans-serif"
  },
  button: {
    backgroundColor: "#25D366",
    width: "65px",
    height: "65px",
    borderRadius: "50%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    textDecoration: "none",
    boxShadow: "0 10px 25px rgba(0,0,0,0.15)",
    transition: "all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)",
    cursor: "pointer",
    border: "2px solid white"
  },
  tooltip: {
    backgroundColor: "white",
    padding: "12px 20px",
    borderRadius: "15px 15px 0 15px",
    boxShadow: "0 10px 25px rgba(0,0,0,0.1)",
    marginBottom: "15px",
    fontSize: "14px",
    fontWeight: "600",
    color: "#1f2937",
    display: "flex",
    alignItems: "center",
    gap: "10px",
    transition: "all 0.5s ease",
    position: "relative",
    whiteSpace: "nowrap",
    border: "1px solid rgba(0,0,0,0.05)"
  },
  statusDot: {
    width: "8px",
    height: "8px",
    backgroundColor: "#25D366",
    borderRadius: "50%",
    display: "inline-block",
    animation: "pulse 2s infinite"
  },
  closeTooltip: {
    background: "none",
    border: "none",
    color: "#9ca3af",
    cursor: "pointer",
    fontSize: "12px",
    padding: "0 0 0 10px"
  }
};

const cssAnimations = `
  @keyframes pulse {
    0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.7); }
    70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(37, 211, 102, 0); }
    100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(37, 211, 102, 0); }
  }
`;

export default Whatsapp;